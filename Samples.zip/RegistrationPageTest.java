package Samples;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class RegistrationPageTest extends HelperMethods{
	
	//Element that needs to be used in various methods
	static WebElement signUp;
	
	public static void main(String[] args) throws InterruptedException {
		 //Goes to the registration page
		 driver.get("https://www.interviewstreet.com/recruit2/signup/");
		 
		 //Grabs all the needed WebElements on the page
		 WebElement firstName = tryGetWebElementElseFail("#inputFirstName");
		 WebElement lastName = tryGetWebElementElseFail("#inputLastName");
		 WebElement companyEmail = tryGetWebElementElseFail("#inputEmail");
		 WebElement password = tryGetWebElementElseFail("#inputPassword");
		 WebElement companyName = tryGetWebElementElseFail("#inputCompany");
		 WebElement	number = tryGetWebElementElseFail("#inputNumber");
		 signUp = tryGetWebElementElseFail("a[name='signup_button']");
		 
		 
		 //Testing each required field
		 signUp.click();
		 
		 //Testing that first name is required.
		 WebElement warning =getWarningText();
		performCheck("First Name is required", warning);
		 firstName.sendKeys(RandomStringUtils.randomAlphabetic(10));
		 signUp.click();
		 
		//Since last name is not required, just fill in
		 lastName.sendKeys(RandomStringUtils.randomAlphabetic(10));
		 signUp.click();
		 
		 //Testing that email is required.
		 warning =getWarningText();
		performCheck("Email Address is required", warning);
		 companyEmail.sendKeys(RandomStringUtils.randomAlphabetic(10));
		 signUp.click();
		 
		 //Checking invalid email
		 warning =getWarningText();
		performCheck("Invalid email address", warning);
		 companyEmail.clear();
		 companyEmail.sendKeys(RandomStringUtils.randomAlphabetic(10)+"@gmail.com");
		 signUp.click();
		 
		 //Checking that company email is needed
		 warning =getWarningText();
		performCheck("Please enter your official email address", warning);
		 companyEmail.clear();
		 companyEmail.sendKeys(RandomStringUtils.randomAlphabetic(10)+"@hgfhf.com");
		 signUp.click();
		 
		 //Checking that password is required
		 warning =getWarningText();
		performCheck("Password is required", warning);
		 password.sendKeys(RandomStringUtils.randomAlphabetic(10));
		 signUp.click();
		 
		//Checking that company name is required
		 warning =getWarningText();
		performCheck("Company is required", warning);
		 companyName.sendKeys(RandomStringUtils.randomAlphabetic(10));
		 signUp.click();
		 
		//Checking that phone number is required
		 warning =getWarningText();
		performCheck("Phone Number is required", warning);
		 number.sendKeys(RandomStringUtils.randomAlphabetic(10));
		 signUp.click();
		 
		//Checking that valid phone number is needed
		 warning =getWarningText();
		performCheck("Invalid phone number", warning);
		 number.clear();
		 number.sendKeys(RandomStringUtils.randomNumeric(10));
		 signUp.click();
		 Thread.sleep(1000);
		 signUp.click();
		
		 //Wait for page to load
		 Thread.sleep(5000);
		 
		 //Checking that Sign up was successful
		 if(waitForElement(10000, "a[class*='cancel-button']")){
			 System.out.println("Registration was successful");
		 }else{
			 System.out.println("Registration was not successful");
		 }
		 driver.close();
	 }
	 
	 /**
	  * Gets all warning values on the page and returns the one that is not empty which is the error message we are looking for.
	  * @param signUp
	  * @return the webelement where the text is not empty
	  * @throws InterruptedException
	  */
	 public static WebElement getWarningText() throws InterruptedException{
		 //Click sign up again since it can fail to submit on first try some times it seems.
		 Thread.sleep(100);
		 signUp.click();
		 Thread.sleep(100);
		 List<WebElement> warnings = driver.findElements(By.cssSelector(".popover-content"));
		for(WebElement e : warnings){
			if(!"".equals(e.getText())){
				return e;
			}
		}
		return null;
	 }
}
