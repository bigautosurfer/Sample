package Samples;

import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebElement;

public class SettingPageTest extends HelperMethods{

	//test account created using these values
	 static String passwordKey = "12121212";
	 static String emailKey = "c2548261@drdrb.com";
	 
	 public static void main(String[] args) throws InterruptedException {

		 driver.get("https://www.interviewstreet.com/recruit2/login/");
		 
		 //Grabs all the needed WebElements on the page
		 WebElement email = tryGetWebElementElseFail("#email");
		 WebElement password = tryGetWebElementElseFail("#password");
		 WebElement signUp = tryGetWebElementElseFail("#login_action");
		 
		 //logs in
		 email.sendKeys(emailKey);
		 password.sendKeys(passwordKey);
		 signUp.click();
		 
		 //Wait For Page to load
		 Thread.sleep(10000);
		 
		
		 waitForElement(10000, "a[class*='cancel-button']");
		 WebElement No =  tryGetWebElement("a[class*='cancel-button']");
		 No.click();
		 
		 //goes to the setting page since setting page has url no need to click dropdown >settings
		 driver.get("https://www.interviewstreet.com/recruit2/recruiter#settings");
		 
		 //Random fill out all fields and store the values into a map
		 List<WebElement> fillableFields = tryGetWebElements("input[type='text']");
		 HashMap<String, String> valuesFilled = new HashMap<String, String>();
		 for(WebElement e: fillableFields){
			 //Gets only the fields related to the settings page and set them
			 if( e.isDisplayed() && e.isEnabled() && !e.getAttribute("value").equals("")){
			 String randomValue = RandomStringUtils.randomAlphabetic(10);
			 e.clear();
			 e.sendKeys(randomValue);
			 valuesFilled.put(e.getAttribute("name"), randomValue);
			 }
		 }
		 
		 //Get the save button and click it
		 WebElement save = tryGetWebElementElseFail("a[class*='basic-submit']");
		 save.click();
		 
		 //Fills out values and check that new values are saved correctly.
		 Thread.sleep(1000);
		 for(Entry<String, String> entry :valuesFilled.entrySet()){
			 WebElement field = tryGetWebElement("input[name='"+entry.getKey()+"']");
			 if(field == null){
				 System.out.println(entry.getKey() +" not found after saving");
			 }else{
				 if(entry.getValue().equals(field.getAttribute("value"))){
					 System.out.println("New value matches with saved value "+entry.getValue() +" for field "+entry.getKey());
				 }else{
					 System.out.println("Values did not match "+field.getAttribute("value") +" to " +entry.getValue());
				 }
			 }
		 }
		 driver.close();
		 
		 //Was not able to complete drop down because I couldn't find the html code for the options on the page
	 }
}
