package Samples;

import org.openqa.selenium.WebElement;

public class LoginPageTest extends HelperMethods {
	//test account created using these values
	 static String passwordKey = "12121212";
	 static String emailKey = "c2548261@drdrb.com";
	 
	 public static void main(String[] args) throws InterruptedException {
		 
		 //Goes to the registration page
		 driver.get("https://www.interviewstreet.com/recruit2/login/");
		 
		 //Grabs all the needed WebElements on the page
		 WebElement email = tryGetWebElementElseFail("#email");
		 WebElement password = tryGetWebElementElseFail("#password");
		 WebElement signUp = tryGetWebElementElseFail("#login_action");
		 
		 //Testing no password and no email
		 signUp.click();
		 WebElement warning = tryGetWebElement("div[class*='message info']");
		 if(checkWarning(warning, "Please enter your registered e-mail address.")){
			 System.out.println("No email and no password -- warning appears");
		 }else{
			 System.out.println("No email and no password --  no warning appears");
		 }
		 
		 //Testing random email with no password
		 email.sendKeys(emailKey);
		 signUp.click();
		 warning = tryGetWebElement("div[class*='message info']");
		 if(checkWarning(warning, "Please enter a password.")){
			 System.out.println("Email and no password -- warning appears");
		 }else{
			 System.out.println("Email and no password --  no warning appears");
		 }
		 email.clear();
		 
		 //Testing no email with  password
		 password.sendKeys(passwordKey);
		 signUp.click();
		 warning = tryGetWebElement("div[class*='message info']");
		 if(checkWarning(warning, "Please enter your registered e-mail address.")){
			 System.out.println("NO Email and password -- warning appears");
		 }else{
			 System.out.println("No Email and no password --  no warning appears");
		 }
		 password.clear();
		 
		 //Testing email with wrong password
		 email.sendKeys(emailKey);
		 password.sendKeys(emailKey);
		 signUp.click();
		 warning = tryGetWebElement("div[class*='message text-error']");
		 if(checkWarning(warning, "Login Failed. Please check username/password.")){
			 System.out.println(" Email and with wrong password -- warning appears");
		 }else{
			 System.out.println(" Email and wrong password --  no warning appears");
		 }
		 email.clear();
		 password.clear();
		 
		 //Testing wrong email with password
		 email.sendKeys(passwordKey);
		 password.sendKeys(passwordKey);
		 signUp.click();
		 warning = tryGetWebElement("div[class*='message text-error']");
		 if(checkWarning(warning, "Login Failed. Please check username/password.")){
			 System.out.println("Wrong email and with wrong password -- warning appears");
		 }else{
			 System.out.println("Wrong email and with wrong password --  no warning appears");
		 }
		 email.clear();
		 password.clear();
		 
		 //Testing email with password
		 email.sendKeys(emailKey);
		 password.sendKeys(passwordKey);
		 signUp.click();
		 
		 //Wait For Page to load
		 Thread.sleep(10000);
		
		 //Testing that login was successful
		 if(waitForElement(10000, "#createNewTest")){
			 System.out.println("Login successful");
		 }else{
			 System.out.println("Login not successful");
		 }
		 driver.close();
	 }
}
