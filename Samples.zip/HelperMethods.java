package Samples;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HelperMethods {
	 protected static WebDriver driver = new FirefoxDriver();
	 
	 
	 /**
	  * Method to try to find a WebElement and fail if cannot be found.
	  * @param css
	  * @return element else fail test
	  */
	 public static WebElement tryGetWebElementElseFail(String css){
		 try{
			 return driver.findElement(By.cssSelector(css));
		 }catch(Exception e){
			 Assert.fail(css +"  Element was not found on page script will fail");
		 }
		 return null;
	 }
	 
	 /**
	  * Method to fined a WebElement and return null if it cannot be found.
	  * @param css
	  * @return element else return null
	  * @throws InterruptedException
	  */
	 public static WebElement tryGetWebElement(String css) throws InterruptedException{
		 Thread.sleep(1000);
		 try{
			 return driver.findElement(By.cssSelector(css));
		 }catch(Exception e){

		 }
		 return null;
	 }
	 
	 /**
	  * Method to fined a WebElement and return null if it cannot be found.
	  * @param css
	  * @return element else return null
	  * @throws InterruptedException
	  */
	 public static List<WebElement> tryGetWebElements(String css) throws InterruptedException{
		 Thread.sleep(1000);
		 try{
			 return driver.findElements(By.cssSelector(css));
		 }catch(Exception e){

		 }
		 return null;
	 }
	 
	 /**
	  * Method to check if the element appears on the within the given time frame
	  * @param timeLimit
	  * @param css
	  * @return true if element is found else false
	  * @throws InterruptedException
	  */
	 public static boolean waitForElement(long timeLimit, String css) throws InterruptedException{
		 long startTime = System.currentTimeMillis();
		 WebElement e = null;
		 while (System.currentTimeMillis() <(startTime+timeLimit)){
			 e = tryGetWebElement(css);
			 if(e!=null){
				 break;
			 }
		 }
		 return e != null;
	 }
	 
	 /**
	  * Helper method to check if warning matches what was expected
	  * @param e
	  * @param warning
	  * @return true if warning matches false if not
	  */
	 public static boolean checkWarning(WebElement e, String warning){
		 if(e== null){
			 return false;
		 }else{
			 return warning.equals(e.getText());
		 }
	 }
	 
	 
	 /**
	  * Helper method to print out result 
	  * @param message
	  * @throws InterruptedException
	  */
	 public static void performCheck(String message, WebElement warning) throws InterruptedException{
		 if(checkWarning(warning, message)){
			 System.out.println("PASS --- "+ message);
		 }else{
			 System.out.println("FAIL --- "+ message );
		 }
	 }
}
